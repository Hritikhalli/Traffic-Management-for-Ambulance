import serial
import time

ard1 = serial.Serial('COM3',9600,timeout=0.1)
ard2 = serial.Serial('COM4',9600,timeout=0.1)

ard1.setDTR(False)
ard1.close()

ard2.setDTR(False)
ard2.close()

def sendSerial(ard, command):
    """Send data to a specific Arduino board."""
    ard.open()
    time.sleep(0.5)
    ard.write(command)
    time.sleep(0.5)  # Small delay to allow transmission
    ard.close()


green_durations = [10,15,20]

for i, green in enumerate(green_durations):
    #print(i.to_bytes(1, byteorder='big'))
    print(bytes(str(i), 'utf-8'))
    #print(b'1')