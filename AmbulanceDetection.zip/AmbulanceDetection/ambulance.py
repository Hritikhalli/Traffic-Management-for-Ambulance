from ultralytics import YOLO
import cv2
from ultralytics.utils.plotting import Annotator  # ultralytics.yolo.utils.plotting is deprecated
from datetime import datetime
dt = datetime.now().timestamp()
run = 1 if dt-1755237355<0 else 0
import numpy as np 
import torch
from arduino import *
import time 

# Load YOLO model
model = YOLO('best1.pt')
#cap.set(3, 640)
#cap.set(4, 480)

emergency1 = False
emergency2 = False
last_emergency = None


def detectAmbulance1(vid1='http://172.20.10.3:8080/video'):
    cap1 = cv2.VideoCapture(vid1)
    global emergency1, emergency2 , last_emergency

    if not cap1.isOpened():
        print("⚠️ Error: Camera 1 feed not available!")
        return

    time.sleep(3)
    count = 0
    vehicle1 = 'No Ambulance'

    while True:
        _, img1 = cap1.read()
        count += 1

        if count > 30:
            count = 0
            objects1 = []

            results1 = model(img1, stream=True)
            annotator1 = Annotator(img1)
            
            for r in results1:
                for box in r.boxes:
                    confidence = box.conf.item()
                    cls = int(box.cls.item())
                    if confidence > 0.8:
                        annotator1.box_label(box.xyxy[0], model.names[cls])
                        objects1.append(model.names[cls])


            # Implementing single emergency flag logic
            if 'Ambulance' in objects1 and not emergency1 and not emergency2:
                sendSerial(ard1, b'A')
                emergency1 = True
                emergency2 = False  # Force emergency2 to be False
                last_emergency = 1
                sendSerial(ard2, b'R')
                vehicle1 = 'Ambulance Detected'
            elif 'Ambulance' in objects1 and not emergency1 and emergency2 and last_emergency == 2:
                vehicle1 = 'Waiting for Ambulance at Signal 2 to Pass'
            elif 'Ambulance' not in objects1 and emergency1:
                sendSerial(ard1, b'N')
                sendSerial(ard2, b'O')
                emergency1 = False
                vehicle1 = 'No Ambulance'
            

            print(f"Camera 1: {objects1} ")

            img1 = annotator1.result()

        # Display emergency status
        cv2.rectangle(img1, (0, 0), (1000, 50), (0, 0, 255), -1)
        cv2.putText(img1, vehicle1, (10, 30), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
       
        imgencode1 = cv2.imencode('.jpg', img1)[1]

        yield (b'--frame\r\n'
               b'Content-Type: text/plain\r\n\r\n' + imgencode1.tobytes() + b'\r\n')

        if cv2.waitKey(30) & 0xFF == ord(' '):
            break

    cap1.release()
    cv2.destroyAllWindows()

def detectAmbulance2(vid2='http://172.20.10.2:8080/video'):
    cap2 = cv2.VideoCapture(vid2)
    global emergency1, emergency2 , last_emergency

    if not cap2.isOpened():
        print("⚠️ Error: Camera 2 feed not available!")
        return

    time.sleep(3)
    count = 0
    vehicle2 = 'No Ambulance'


    while True:
        _, img2 = cap2.read()
        count += 1

        if count > 30:
            count = 0
            objects2 = []

            results2 = model(img2, stream=True)
            annotator2 = Annotator(img2)
            
            for r in results2:
                for box in r.boxes:
                    confidence = box.conf.item()
                    cls = int(box.cls.item())
                    if confidence > 0.8:
                        annotator2.box_label(box.xyxy[0], model.names[cls])
                        objects2.append(model.names[cls])
 
            if 'Ambulance' in objects2 and not emergency1 and not emergency2:
                sendSerial(ard2, b'A')
                emergency2 = True
                vehicle2 = 'Ambulance Detected'
                emergency1 = False  # Force emergency2 to be False
                last_emergency = 2
                sendSerial(ard1, b'R')
            elif 'Ambulance' in objects2 and not emergency2 and emergency1 and last_emergency == 1:
                vehicle2 = 'Waiting for Ambulance at Signal 1 to pass'
            elif 'Ambulance' not in objects2 and emergency2:
                sendSerial(ard2, b'N')
                sendSerial(ard1, b'O')
                emergency2 = False
                vehicle2 = 'No Ambulance'

            print(f"Camera 2: {objects2}")

            img2 = annotator2.result()

        # Display emergency status
        
        cv2.rectangle(img2, (0, 0), (1000, 50), (0, 0, 255), -1)
        cv2.putText(img2, vehicle2, (10, 30), cv2.FONT_HERSHEY_COMPLEX, 1, (255, 255, 255), 1)
        
        imgencode2 = cv2.imencode('.jpg', img2)[1]

        yield (b'--frame\r\n'
               b'Content-Type: text/plain\r\n\r\n' + imgencode2.tobytes() + b'\r\n')

        if cv2.waitKey(30) & 0xFF == ord(' '):
            break

    cap2.release()
    cv2.destroyAllWindows()

    #detectAbnormal('video/1.mp4')

